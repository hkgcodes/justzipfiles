package com.nwg.LogMaskerV3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogMaskerV3Application {

	public static void main(String[] args) {
		SpringApplication.run(LogMaskerV3Application.class, args);
	}

}
